﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Windows.Forms
Imports System.Collections

<ComVisible(True)>
Public Class RenomearFolhasAddIn
    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Executar()
        Try
            ' === Verifica se o documento ativo é um desenho ===
            Dim dwgDoc As DrawingDocument = TryCast(_app.ActiveDocument, DrawingDocument)
            If dwgDoc Is Nothing Then
                MessageBox.Show("O documento ativo não é um desenho (.idw ou .dwg).", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            ' === Coleta nomes das folhas ===
            Dim allSheetNames As New List(Of String)
            For Each sht As Sheet In dwgDoc.Sheets
                allSheetNames.Add(sht.Name)
            Next

            ' === Interface de seleção das folhas ===
            Dim selectedSheets As IEnumerable(Of Object) =
                MultiSelectListBoxWithPrefixFilter("Selecione as folhas para renomear:", allSheetNames, Nothing, "Renomear Folhas", "Folhas do desenho")

            If selectedSheets Is Nothing OrElse selectedSheets.Count = 0 Then
                MessageBox.Show("Nenhuma folha foi selecionada.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

            If selectedSheets.Contains("**[Selecionar Todas]**") Then
                selectedSheets = dwgDoc.Sheets.Cast(Of Sheet).Select(Function(s) s.Name).ToList()
            End If

            ' === Tenta obter o BOM ===
            Dim BOMRows As BOMRowsEnumerator = GetBOMRows(dwgDoc)
            If BOMRows Is Nothing Then
                MessageBox.Show("Erro ao obter o BOM da montagem principal (pode não haver montagem referenciada).", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            Dim renomeadas As New StringBuilder()
            Dim novosNomes As New List(Of String)

            ' === Loop pelas folhas ===
            For Each dwgSheet As Sheet In dwgDoc.Sheets
                If selectedSheets.Contains(dwgSheet.Name) Then
                    Try
                        If dwgSheet.DrawingViews.Count = 0 Then Continue For

                        Dim refDoc As Document = Nothing

                        ' Localiza a primeira vista válida
                        For Each view As DrawingView In dwgSheet.DrawingViews
                            Try
                                Dim tempDoc As Document = view.ReferencedDocumentDescriptor.ReferencedDocument
                                If tempDoc IsNot Nothing AndAlso
                                   (tempDoc.DocumentType = DocumentTypeEnum.kPartDocumentObject OrElse
                                    tempDoc.DocumentType = DocumentTypeEnum.kAssemblyDocumentObject) Then
                                    refDoc = tempDoc
                                    Exit For
                                End If
                            Catch
                            End Try
                        Next

                        If refDoc Is Nothing Then Continue For

                        Dim docFName As String = System.IO.Path.GetFileName(refDoc.FullFileName)

                        ' === Propriedades ===
                        Dim codPeca As String = SanitizeText(SafeGetPropertyValue(refDoc, "Design Tracking Properties", "Número da peça"))
                        If codPeca = "X" Then codPeca = SanitizeText(SafeGetPropertyValue(refDoc, "Design Tracking Properties", "Part Number"))

                        Dim descricao As String = SanitizeText(SafeGetPropertyValue(refDoc, "Design Tracking Properties", "Descrição"))
                        If descricao = "X" Then descricao = SanitizeText(SafeGetPropertyValue(refDoc, "Design Tracking Properties", "Description"))

                        ' === Categoria (Summary.Category) ===
                        Dim categoryRaw As String = ""
                        Try
                            categoryRaw = refDoc.PropertySets.Item("Summary").Item("Category").Value
                        Catch
                            categoryRaw = ""
                        End Try

                        Dim categoria As String
                        If categoryRaw.Contains(" - ") Then
                            categoria = categoryRaw.Split("-"c)(0).Trim()
                        Else
                            categoria = categoryRaw.Trim()
                        End If
                        If categoria = "" Then categoria = "N-A"

                        ' === Item BOM ===
                        Dim itemBOM As String = ""
                        If BOMRows IsNot Nothing Then itemBOM = SearchBOMByPartNumber(BOMRows, codPeca)
                        If String.IsNullOrEmpty(itemBOM) Then itemBOM = "N-A"

                        ' === Verificação de dados ===
                        If categoria = "N-A" Or descricao = "X" Or codPeca = "X" Then Continue For

                        ' === Novo nome ===
                        Dim novoNome As String = categoria & " - " & itemBOM & " - " & codPeca
                        If IsAssemblyDocument(refDoc.FullFileName) AndAlso Not novoNome.EndsWith("ASS'Y") Then
                            novoNome &= " ASS'Y"
                        End If

                        ' Evita duplicatas
                        If novosNomes.Contains(novoNome) Then
                            novoNome &= " (" & Now.Ticks.ToString().Substring(10) & ")"
                        End If

                        novosNomes.Add(novoNome)
                        renomeadas.AppendLine("• " & dwgSheet.Name & " → " & novoNome)

                        ' === Renomeia de fato ===
                        dwgSheet.Name = novoNome

                    Catch ex As Exception
                        MessageBox.Show("Erro ao renomear a folha '" & dwgSheet.Name & "': " & ex.Message)
                    End Try
                End If
            Next

            ' === Atualiza e salva ===
            dwgDoc.Update()
            dwgDoc.Save2(True)

            ' === Exibe resultado ===
            ShowFormattedResults(renomeadas.ToString())

        Catch ex As Exception
            MessageBox.Show("Erro ao executar renomeação: " & ex.Message)
        End Try
    End Sub

    ' ========================================================================================
    ' ============================ FUNÇÕES AUXILIARES =======================================
    ' ========================================================================================

    Private Function SafeGetPropertyValue(doc As Document, propSetName As String, propName As String) As String
        Try
            Return doc.PropertySets.Item(propSetName).Item(propName).Value
        Catch
            Return "X"
        End Try
    End Function

    Private Function SanitizeText(inputText As String) As String
        If inputText Is Nothing Then Return ""
        Dim invalidChars As String = "<>:,""\/|?*{}[]()'´`"
        For Each c As Char In invalidChars
            inputText = inputText.Replace(c, "_")
        Next
        inputText = System.Text.RegularExpressions.Regex.Replace(inputText, "\s+", " ")
        Return inputText.Trim()
    End Function

    Private Function GetBOMRows(dwgDoc As DrawingDocument) As BOMRowsEnumerator
        Try
            Dim firstSheet As Sheet = dwgDoc.Sheets.Item(1)
            If firstSheet.DrawingViews.Count = 0 Then Return Nothing
            Dim refDoc As Document = firstSheet.DrawingViews(1).ReferencedDocumentDescriptor.ReferencedDocument
            If Not TypeOf refDoc Is AssemblyDocument Then Return Nothing

            Dim asmDoc As AssemblyDocument = CType(refDoc, AssemblyDocument)
            With asmDoc.ComponentDefinition.BOM
                .StructuredViewEnabled = True
                .StructuredViewFirstLevelOnly = False
                For Each view As BOMView In .BOMViews
                    If view.ViewType = BOMViewTypeEnum.kStructuredBOMViewType Then
                        Return view.BOMRows
                    End If
                Next
            End With
        Catch
        End Try
        Return Nothing
    End Function

    Private Function SearchBOMByPartNumber(rows As BOMRowsEnumerator, targetPartNumber As String) As String
        Dim targetSanitized As String = SanitizeText(targetPartNumber).Trim().ToUpper()
        For Each Row As BOMRow In rows
            Try
                If Row.ComponentDefinitions.Count = 0 Then Continue For
                Dim def As ComponentDefinition = Row.ComponentDefinitions.Item(1)
                Dim doc As Document = def.Document
                Dim rowPartNumber As String = ""
                Try
                    rowPartNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value
                Catch
                    rowPartNumber = ""
                End Try
                Dim rowSanitized As String = SanitizeText(rowPartNumber).Trim().ToUpper()
                If rowSanitized = targetSanitized Then
                    Return Row.ItemNumber
                End If
                If Row.ChildRows IsNot Nothing Then
                    Dim childResult As String = SearchBOMByPartNumber(Row.ChildRows, targetPartNumber)
                    If childResult <> "" Then Return childResult
                End If
            Catch
            End Try
        Next
        Return ""
    End Function

    Private Function IsAssemblyDocument(filePath As String) As Boolean
        Try
            Return UCase(System.IO.Path.GetExtension(filePath)) = ".IAM"
        Catch
            Return False
        End Try
    End Function

    Private Sub ShowFormattedResults(message As String)
        Dim form As New Form With {.Text = "RESULTADO DA RENOMEAÇÃO", .Width = 1200, .Height = 700}
        Dim richText As New RichTextBox With {.Dock = DockStyle.Fill, .ReadOnly = True}
        richText.AppendText("RENOMEAÇÃO CONCLUÍDA:" & vbCrLf & vbCrLf)
        richText.AppendText(message)
        form.Controls.Add(richText)
        form.ShowDialog()
    End Sub

    ' ========================================================================================
    ' ============= INTERFACE DE MULTI-SELEÇÃO COM FILTRO ===================================
    ' ========================================================================================

    Private Function MultiSelectListBoxWithPrefixFilter(Optional Instructions As String = "", Optional Items As IEnumerable = Nothing, Optional DefaultValue As Object = Nothing, Optional Title As String = "", Optional ListName As String = "") As IEnumerable(Of Object)
        Dim form As New Form With {.Text = If(Title <> "", Title, "Seleção de Itens"), .Width = 600, .Height = 700, .StartPosition = FormStartPosition.CenterScreen}
        Dim label As New Label With {.Text = Instructions, .Dock = DockStyle.Top, .Height = 20}
        form.Controls.Add(label)
        Dim clb As New CheckedListBox With {.CheckOnClick = True, .Dock = DockStyle.Top, .Height = 450}
        form.Controls.Add(clb)
        Dim prefixTextBox As New System.Windows.Forms.TextBox With {.Dock = DockStyle.Top, .Height = 25}
        form.Controls.Add(prefixTextBox)
        Dim btnFilter As New Button With {.Text = "Aplicar Filtro", .Dock = DockStyle.Top, .Height = 30}
        AddHandler btnFilter.Click, Sub()
                                        Dim prefix As String = prefixTextBox.Text.Trim()
                                        clb.Items.Clear()
                                        For Each item In Items
                                            If prefix = "" OrElse item.ToString().StartsWith(prefix, StringComparison.CurrentCultureIgnoreCase) Then
                                                clb.Items.Add(item, False)
                                            End If
                                        Next
                                    End Sub
        form.Controls.Add(btnFilter)
        Dim btnMarcarTodas As New Button With {.Text = "Marcar Todas", .Dock = DockStyle.Top, .Height = 30}
        AddHandler btnMarcarTodas.Click, Sub()
                                             For i As Integer = 0 To clb.Items.Count - 1
                                                 clb.SetItemChecked(i, True)
                                             Next
                                         End Sub
        form.Controls.Add(btnMarcarTodas)
        Dim btnDesmarcarTodas As New Button With {.Text = "Desmarcar Todas", .Dock = DockStyle.Top, .Height = 30}
        AddHandler btnDesmarcarTodas.Click, Sub()
                                                For i As Integer = 0 To clb.Items.Count - 1
                                                    clb.SetItemChecked(i, False)
                                                Next
                                            End Sub
        form.Controls.Add(btnDesmarcarTodas)
        Dim okButton As New Button With {.Text = "Confirmar Seleção", .Dock = DockStyle.Bottom, .Height = 30}
        AddHandler okButton.Click, Sub() form.DialogResult = DialogResult.OK
        form.Controls.Add(okButton)
        For Each item In Items
            clb.Items.Add(item, False)
        Next
        If form.ShowDialog() = DialogResult.OK Then
            Dim selectedItems As New List(Of Object)
            For Each item In clb.CheckedItems
                selectedItems.Add(item)
            Next
            Return selectedItems
        Else
            Return Nothing
        End If
    End Function
End Class
