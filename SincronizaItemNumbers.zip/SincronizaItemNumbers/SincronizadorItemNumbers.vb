﻿Imports System.Linq
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Windows.Forms
Imports Inventor
Imports IO = System.IO ' Alias para evitar ambiguidade com Inventor.Path

<ComVisible(True)>
Public Class SincronizadorItemNumbers
    Private ReadOnly _app As Inventor.Application
    Private _erros As New List(Of String) ' Para registrar erros sem interromper

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub ExecutarSincronizacao()
        Try
            Dim doc As Document = _app.ActiveDocument
            If doc Is Nothing OrElse doc.DocumentType <> DocumentTypeEnum.kAssemblyDocumentObject Then
                MessageBox.Show("Abra uma montagem antes de rodar esta função.", "Documento inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Dim asmDoc As AssemblyDocument = CType(doc, AssemblyDocument)
            Dim raizDisplayName As String = asmDoc.DisplayName

            Dim mapaGlobal As List(Of Tuple(Of String, String, String)) = ObterMapaCompleto(asmDoc)
            If mapaGlobal Is Nothing OrElse mapaGlobal.Count = 0 Then
                MessageBox.Show("Nenhum item encontrado no BOM estruturado da montagem.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            SincronizarSubmontagensRecursivo(asmDoc, mapaGlobal, raizDisplayName)
            ShowFormattedResults(FormatarMapaParaTexto(mapaGlobal))

            'MessageBox.Show("Sincronização concluída com sucesso! A montagem principal foi preservada.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            'MessageBox.Show("Erro inesperado durante a sincronização: " & ex.Message, "Erro geral", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ShowFormattedResults(message As String)
        Try
            Dim form As New Form With {.Text = "RESULTADO DA SINCRONIZAÇÃO", .Width = 1000, .Height = 600}
            Dim richText As New RichTextBox With {.Dock = DockStyle.Fill, .ReadOnly = True}
            richText.AppendText("MAPA DE SINCRONIZAÇÃO:" & vbCrLf & vbCrLf & message)
            form.Controls.Add(richText)
            form.ShowDialog()
        Catch
            'ignora erro ao mostrar o formulário
        End Try
    End Sub

    Private Function FormatarMapaParaTexto(mapa As List(Of Tuple(Of String, String, String))) As String
        Dim sb As New StringBuilder()
        sb.AppendLine("PART NUMBER".PadRight(70) & "ITEM NUMBER".PadRight(30) & "CAMINHO HIERÁRQUICO")
        sb.AppendLine(New String("-"c, 170))
        For Each item In mapa
            sb.AppendLine(item.Item1.PadRight(70) & item.Item2.PadRight(30) & item.Item3)
        Next
        Return sb.ToString()
    End Function

    Private Function ObterMapaCompleto(asm As AssemblyDocument) As List(Of Tuple(Of String, String, String))
        Dim mapa As New List(Of Tuple(Of String, String, String))()
        Try
            Dim bom As BOM = asm.ComponentDefinition.BOM
            If Not bom.StructuredViewEnabled Then bom.StructuredViewEnabled = True
            bom.StructuredViewFirstLevelOnly = False

            Dim view As BOMView = bom.BOMViews.Cast(Of BOMView)() _
                .FirstOrDefault(Function(v) v.ViewType = BOMViewTypeEnum.kStructuredBOMViewType)

            If view Is Nothing Then Return mapa

            For Each row As BOMRow In view.BOMRows
                Try
                    AdicionarAoMapaRecursivo(row, mapa, asm.DisplayName)
                Catch ex As Exception
                    _erros.Add("Erro no BOMRow: " & ex.Message)
                End Try
            Next
        Catch ex As Exception
            _erros.Add("Erro ao construir mapa completo: " & ex.Message)
        End Try
        Return mapa
    End Function

    Private Sub AdicionarAoMapaRecursivo(row As BOMRow, mapa As List(Of Tuple(Of String, String, String)), parentPath As String)
        Try
            If row Is Nothing OrElse row.ComponentDefinitions Is Nothing OrElse row.ComponentDefinitions.Count = 0 Then Exit Sub
            Dim doc As Document = row.ComponentDefinitions.Item(1).Document
            Dim partNumber As String = ""
            Try
                partNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
            Catch ex As Exception
                'ignora erro individual de propriedade
            End Try

            Dim itemNumber As String = row.ItemNumber
            Dim caminho As String = IO.Path.Combine(parentPath, IO.Path.GetFileNameWithoutExtension(doc.FullFileName))

            If Not String.IsNullOrEmpty(partNumber) Then
                mapa.Add(Tuple.Create(partNumber, itemNumber, caminho))
            End If

            If row.ChildRows IsNot Nothing Then
                For Each child As BOMRow In row.ChildRows
                    Try
                        AdicionarAoMapaRecursivo(child, mapa, caminho)
                    Catch ex As Exception
                        _erros.Add("Erro em sublinha: " & ex.Message)
                    End Try
                Next
            End If
        Catch ex As Exception
            _erros.Add("Erro ao adicionar ao mapa: " & ex.Message)
        End Try
    End Sub

    Private Sub SincronizarItemNumbers(mapaGlobal As List(Of Tuple(Of String, String, String)), asm As AssemblyDocument, subPath As String)
        Try
            Dim bom As BOM = asm.ComponentDefinition.BOM
            If Not bom.StructuredViewEnabled Then bom.StructuredViewEnabled = True
            bom.StructuredViewFirstLevelOnly = True

            Dim view As BOMView = bom.BOMViews.Cast(Of BOMView)() _
                .FirstOrDefault(Function(v) v.ViewType = BOMViewTypeEnum.kStructuredBOMViewType)

            If view Is Nothing Then Return

            For Each row As BOMRow In view.BOMRows
                Try
                    If row.ComponentDefinitions Is Nothing OrElse row.ComponentDefinitions.Count = 0 Then Continue For

                    Dim doc As Document = Nothing
                    Try
                        doc = row.ComponentDefinitions.Item(1).Document
                    Catch
                        Continue For
                    End Try

                    Dim partNumber As String = ""
                    Try
                        partNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
                    Catch
                        Continue For
                    End Try

                    Dim caminhoAtual As String = IO.Path.Combine(subPath, IO.Path.GetFileNameWithoutExtension(doc.FullFileName))

                    Dim itemNumberCorreto As String = mapaGlobal _
                        .Where(Function(t) t.Item1 = partNumber AndAlso t.Item3 = caminhoAtual) _
                        .Select(Function(t) t.Item2) _
                        .FirstOrDefault()

                    If String.IsNullOrWhiteSpace(itemNumberCorreto) Then
                        itemNumberCorreto = mapaGlobal _
                            .Where(Function(t) t.Item1 = partNumber) _
                            .Select(Function(t) t.Item2) _
                            .FirstOrDefault()
                    End If

                    If Not String.IsNullOrWhiteSpace(itemNumberCorreto) AndAlso row.ItemNumber <> itemNumberCorreto Then
                        row.ItemNumber = itemNumberCorreto
                    End If
                Catch ex As Exception
                    _erros.Add("Erro sincronizando item: " & ex.Message)
                End Try
            Next
        Catch ex As Exception
            _erros.Add("Erro geral sincronizando item numbers: " & ex.Message)
        End Try
    End Sub

    Private Sub SincronizarSubmontagensRecursivo(asm As AssemblyDocument, mapaGlobal As List(Of Tuple(Of String, String, String)), raizDisplayName As String)
        Try
            For Each occ As ComponentOccurrence In asm.ComponentDefinition.Occurrences
                Try
                    If occ.DefinitionDocumentType = DocumentTypeEnum.kAssemblyDocumentObject Then
                        Dim subAsm As AssemblyDocument = Nothing
                        Try
                            subAsm = TryCast(_app.Documents.Item(occ.Definition.Document.FullFileName), AssemblyDocument)
                        Catch
                            Try
                                subAsm = TryCast(_app.Documents.Open(occ.Definition.Document.FullFileName, False), AssemblyDocument)
                            Catch
                                _erros.Add("Não foi possível abrir submontagem: " & occ.Name)
                                Continue For
                            End Try
                        End Try

                        If subAsm Is Nothing Then Continue For

                        Dim subPath As String = IO.Path.Combine(raizDisplayName, IO.Path.GetFileNameWithoutExtension(subAsm.FullFileName))

                        SincronizarItemNumbers(mapaGlobal, subAsm, subPath)

                        Try : subAsm.Save2(True) : Catch : End Try
                        SincronizarSubmontagensRecursivo(subAsm, mapaGlobal, raizDisplayName)
                    End If
                Catch ex As Exception
                    _erros.Add("Erro em ocorrência: " & occ.Name & " - " & ex.Message)
                End Try
            Next
        Catch ex As Exception
            _erros.Add("Erro na sincronização recursiva: " & ex.Message)
        End Try
    End Sub
End Class
